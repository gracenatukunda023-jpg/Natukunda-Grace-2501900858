﻿Public Class frmCARRENTALSYSTEM

    Private Sub lblRentalDuration_Click(sender As Object, e As EventArgs) Handles lblRentalDuration.Click

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'Add vehicle types to the ComboBox
        cmbVehicleType.Items.Add("Sedan")
        cmbVehicleType.Items.Add("SUV")
        cmbVehicleType.Items.Add("Truck")

        'Set output fields as read-only
        txtDailyRentalCharge.ReadOnly = True
        txtTotalRentalCost.ReadOnly = True

        'Clear fields
        txtDailyRentalCharge.Clear()
        txtRentalDuration.Clear()
        txtTotalRentalCost.Clear()
    End Sub

    Private Sub lblCARRENTALSYSTEM_Click(sender As Object, e As EventArgs) Handles lblCARRENTALSYSTEM.Click

    End Sub

    Private Sub cmbVehicleType_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbVehicleType.SelectedIndexChanged
        Select Case cmbVehicleType.Text
            Case "Sedan"
                txtDailyRentalCharge.Text = "150000"

            Case "SUV"
                txtDailyRentalCharge.Text = "290000"

            Case "Truck"
                txtDailyRentalCharge.Text = "350000"

            Case Else
                txtDailyRentalCharge.Clear()

        End Select
    End Sub

    Private Sub btnCALCULATE_Click(sender As Object, e As EventArgs) Handles btnCALCULATE.Click
        Dim DailyRentalCharge As Decimal = 0
        Dim rentalDuration As Integer = 0
        Dim totalRentalCost As Decimal = 0

        'Check whether a vehicle has been selected
        If cmbVehicleType.SelectedIndex = -1 Then
            MessageBox.Show("Please select a vehicle type.",
                            "Input Required",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Warning)
            cmbVehicleType.Focus()
            Exit Sub
        End If

        'Check whether rental duration is a valid number
        If Not Integer.TryParse(txtRentalDuration.Text, rentalDuration) OrElse rentalDuration <= 0 Then
            MessageBox.Show("Please enter a valid number of days rented.",
                            "valid Input",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Warning)
            txtRentalDuration.Focus()
            Exit Sub
        End If
        'Calculate daily rental charge
        DailyRentalCharge = Decimal.Parse(txtDailyRentalCharge.Text)

        'Calculate total rental cost
        totalRentalCost = DailyRentalCharge * rentalDuration

        'Display the result
        txtTotalRentalCost.Text = totalRentalCost.ToString()
    End Sub

    Private Sub lblTotalRentalCost_Click(sender As Object, e As EventArgs) Handles lblTotalRentalCost.Click

    End Sub

    Private Sub btnCLEAR_Click(sender As Object, e As EventArgs) Handles btnCLEAR.Click
        cmbVehicleType.SelectedIndex = -1
        txtDailyRentalCharge.Clear()
        txtRentalDuration.Clear()
        txtTotalRentalCost.Clear()

        cmbVehicleType.Focus()

    End Sub
End Class

